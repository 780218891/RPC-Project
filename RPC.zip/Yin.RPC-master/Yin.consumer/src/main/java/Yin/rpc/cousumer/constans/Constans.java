package Yin.rpc.cousumer.constans;

public class Constans {
	public static final String SERVER_PATH="/netty";
}
