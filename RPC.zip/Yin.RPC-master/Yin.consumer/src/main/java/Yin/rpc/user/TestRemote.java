package Yin.rpc.user;

import Yin.rpc.cousumer.param.Response;

public interface TestRemote {
	public Response testUser(User user);
}
