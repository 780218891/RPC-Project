package constants;

public class Constans {
	public static final String SERVER_PATH="/netty";
}
