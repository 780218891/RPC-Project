package service;

import java.util.List;

import org.springframework.stereotype.Service;

import model.User;
@Service
public class UserService {

	public void saveUSer(User user) {
		//数据库层面的操作
		
	}

	public void saveUSerList(List<User> userlist) {
		
	}

}
